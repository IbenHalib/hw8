<?php

namespace Vadim\GuestBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class VadimGuestBundle extends Bundle
{
}
