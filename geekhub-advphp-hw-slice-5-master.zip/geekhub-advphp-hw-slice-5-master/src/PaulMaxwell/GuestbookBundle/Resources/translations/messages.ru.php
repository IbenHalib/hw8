<?php
return array(
    'Welcome to simple guestbook!' => 'Добро пожаловать в простую гостевую книгу!',
    'Simple guestbook' => 'Простая гостевая книга',
    'Name' => 'Имя',
    'E-mail' => 'Мыло',
    'Your message' => 'Ваше сообщение',
    'Fire!' => 'Отжечь!',
    'You can use letters only' => 'Можно использовать только буквы',
);
