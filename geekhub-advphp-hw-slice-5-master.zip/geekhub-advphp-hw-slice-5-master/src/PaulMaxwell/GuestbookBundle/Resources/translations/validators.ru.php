<?php
return array(
    'You can use letters only' => 'Можно использовать только буквы',
);
