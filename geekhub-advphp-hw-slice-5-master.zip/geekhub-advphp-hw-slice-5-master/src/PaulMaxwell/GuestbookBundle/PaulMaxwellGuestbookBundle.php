<?php

namespace PaulMaxwell\GuestbookBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class PaulMaxwellGuestbookBundle extends Bundle
{
}
